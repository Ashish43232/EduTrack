package com.example.EduTrack;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EduTrackApplicationTests {

	@Test
	void contextLoads() {
	}

}
