package com.example.EduTrack.Repository;

import java.util.List;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.EduTrack.Entity.Course;

@Repository
public interface CourseRepo extends JpaRepository<Course, Long> {
	
	//select * from course where studentid = ?
	public List <Course> findCourseByStudentid(Long studentid);
}
