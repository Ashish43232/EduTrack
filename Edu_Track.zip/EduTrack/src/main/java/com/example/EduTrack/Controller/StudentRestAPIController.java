package com.example.EduTrack.Controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.EduTrack.Entity.Course;
import com.example.EduTrack.Entity.Students;
import com.example.EduTrack.Model.LoginRequest;
import com.example.EduTrack.Service.StudentAuthService;
import com.example.EduTrack.Util.JwtTokenUtil;

@RestController
@RequestMapping("/auth/api")
public class StudentRestAPIController {
	
	private StudentAuthService studentAuthService;
	
	StudentRestAPIController(StudentAuthService studentAuthService){
		this.studentAuthService = studentAuthService;
	}
	
	@PostMapping("/login")
	public ResponseEntity<?> doLogin(@RequestBody LoginRequest fromUser) {

	    System.out.println("Param Data: " + fromUser.getEmail() + " " + fromUser.getPassword());

	    Optional<Students> isUserObj = studentAuthService.loginAction(fromUser.getEmail(), fromUser.getPassword());
	    System.out.println(isUserObj);

	    if (isUserObj.isPresent()) {
	        Students stu = isUserObj.get();

	        // Generate token
	        String token = JwtTokenUtil.generateJwtToken(stu.getEmail());
	        stu.setToken(token);

	        System.out.println("Generated Token: " + token); //  Console print for verification

	        //  Return token (and optionally student info)
	        Map<String, Object> response = new HashMap<>();
	        response.put("message", "Login successful");
	        response.put("token", token);
	        response.put("student", stu.getEmail());

	        return ResponseEntity.ok(response);
	    } else {
	        return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
	                .body("User not found or invalid credentials");
	    }
	}

	
	@GetMapping("/getstudentcourse")
	public ResponseEntity<List<Course>> getCourseDetails(@RequestParam("id") Long studentid){
		List<Course> courseLists = studentAuthService.findCourseByStudentId(studentid);
		
		return new ResponseEntity<>(courseLists,HttpStatus.OK);
	}
}
