package com.example.EduTrack.Util;

import java.security.Key;
import java.util.Date;

import io.jsonwebtoken.ExpiredJwtException;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.MalformedJwtException;
import io.jsonwebtoken.UnsupportedJwtException;
import io.jsonwebtoken.io.Decoders;
import io.jsonwebtoken.security.Keys;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.JwtException;

public class JwtTokenUtil {

	private static final String SECRET = "bXlTdXBlclNlY3JldEtleUZvckpXVGF1dGgxMjM0NTY3ODkw"; 
	private static final Key key = Keys.hmacShaKeyFor(Decoders.BASE64.decode(SECRET));
	
	//generating JwtToken
	public static String generateJwtToken(String username) {
		return Jwts.builder()
				.setSubject(username)
				.setIssuedAt(new Date())
				.setExpiration(new Date(System.currentTimeMillis() + 3600000)) //1 hour
				.signWith(key)
				.compact();
	}
	
	//validating the token 
	public static boolean validateToken(String token) {
		try {
			Jwts.parserBuilder()
			.setSigningKey(key)
			.build()
			.parseClaimsJws(token); //throws if invalid
			return true;
		}
		
		catch(ExpiredJwtException e) {
			System.out.println("Token expired:" +e.getMessage());
		}
		
		catch(UnsupportedJwtException e) {
			System.out.println("Unsupported Token:" +e.getMessage());
		}
		
		catch(MalformedJwtException e) {
			System.out.println("Malformed Token:" +e.getMessage());
		}
		
		catch(IllegalArgumentException e) {
			System.out.println("Empty or null Token:" +e.getMessage());
		}
		
		return false;
	}
	
	//helper : extractAllClaims
	public static Claims extractAllClaims(String token) {
		return Jwts.parserBuilder()
				.setSigningKey(key)
				.build()
				.parseClaimsJws(token)
				.getBody();
	}
	
	//extract username from token
	public static String extractUsername(String token) {
		return extractAllClaims(token).getSubject();
	}
	
	//extract expiration
	public static Date extractExpiration(String token) {
		return extractAllClaims(token).getExpiration();
	}
	
	public static boolean validateTokenExpire(String token) {
		try {
			Claims claims = extractAllClaims(token);
			return !claims.getExpiration().before(new Date());
		}
		
		catch(JwtException | IllegalArgumentException e) {
			//token is invalid
			
			e.printStackTrace();
			return false;
		}
	}
	
	
}
