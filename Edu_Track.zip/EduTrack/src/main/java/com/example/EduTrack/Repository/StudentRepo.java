package com.example.EduTrack.Repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.EduTrack.Entity.Students;

@Repository
public interface StudentRepo extends JpaRepository<Students, Long> {
		
	//select * from students where Email = ? and password = ?
	public Optional <Students> findByEmailAndPassword(String email,String password);
}
