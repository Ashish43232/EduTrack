package com.example.EduTrack;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EduTrackApplication {

	public static void main(String[] args) {
		SpringApplication.run(EduTrackApplication.class, args);
	}

}