package com.example.EduTrack.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.example.EduTrack.Entity.Course;
import com.example.EduTrack.Entity.Students;
import com.example.EduTrack.Repository.CourseRepo;
import com.example.EduTrack.Repository.StudentRepo;

@Service
public class StudentAuthService {
		
	private StudentRepo studentRepo;
	private CourseRepo courseRepo;
	
	StudentAuthService(StudentRepo studentRepo,CourseRepo courseRepo){
		this.studentRepo = studentRepo;
		this.courseRepo = courseRepo;
	}
	
	//login action
	
	public Optional<Students> loginAction(String email,String password){
		
		Optional<Students> logedstudent = studentRepo.findByEmailAndPassword(email, password);
		
		return logedstudent;
	}
	
	//getting course details by student id
	
	public List <Course> findCourseByStudentId(Long studentid){
		List<Course> enrolledCourse = courseRepo.findCourseByStudentid(studentid);
		return enrolledCourse;
	}
}
